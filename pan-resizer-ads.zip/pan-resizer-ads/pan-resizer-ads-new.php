<?php
/**
 * Plugin Name: PAN Resizer AdStyle Ads Manager
 * Plugin URI: https://panresizer.in
 * Description: Manage AdStyle ads for PAN Resizer theme with toggle controls
 * Version: 1.0.9
 * Author: PAN Resizer Team
 * Author URI: https://panresizer.in
 * License: GPL v2 or later
 * Text Domain: pan-resizer-ads
 * Requires at least: 5.0
 * Requires PHP: 7.2
 */

// Security check
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct access not allowed' );
}

/**
 * Get default ad codes
 */
function pan_get_default_ads() {
    return array(
        'popunder' => array(
            'code' => '<script src="https://pl28451707.effectivegatecpm.com/84/37/e3/8437e33289be7990e8c5185001c5bb67.js"></script>',
            'enabled' => true
        ),
        'native_banner' => array(
            'code' => '<script async="async" data-cfasync="false" src="https://pl28463080.effectivegatecpm.com/5a2b1a440c7b20849aae55f9bc6756fb/invoke.js"></script>' . "\n" . '<div id="container-5a2b1a440c7b20849aae55f9bc6756fb"></div>',
            'enabled' => true
        ),
        'social_bar' => array(
            'code' => '<script src="https://pl28463176.effectivegatecpm.com/1c/34/72/1c3472a6e894aafb8faa9ec2a9ea5fb2.js"></script>',
            'enabled' => true
        ),
        'smart_link' => array(
            'code' => 'https://www.effectivegatecpm.com/i9xjgf95gf?key=6bca25f48b1e6ecdaa96604682b95879',
            'enabled' => true
        ),
        'banner_1' => array(
            'code' => '<script>
  atOptions = {
    \'key\' : \'91c6c20850bcdda979351c9cecc6b1ab\',
    \'format\' : \'iframe\',
    \'height\' : 300,
    \'width\' : 160,
    \'params\' : {}
  };
</script>
<script src="https://www.highperformanceformat.com/91c6c20850bcdda979351c9cecc6b1ab/invoke.js"></script>',
            'enabled' => true
        ),
        'banner_2' => array(
            'code' => '<script>
  atOptions = {
    \'key\' : \'05784b2ec54ec2f682a1af8703007bc6\',
    \'format\' : \'iframe\',
    \'height\' : 600,
    \'width\' : 160,
    \'params\' : {}
  };
</script>
<script src="https://www.highperformanceformat.com/05784b2ec54ec2f682a1af8703007bc6/invoke.js"></script>',
            'enabled' => true
        ),
        'banner_3' => array(
            'code' => '<script>
  atOptions = {
    \'key\' : \'2643a8840f6c27d533eb5d2fddb5e8b2\',
    \'format\' : \'iframe\',
    \'height\' : 250,
    \'width\' : 300,
    \'params\' : {}
  };
</script>
<script src="https://www.highperformanceformat.com/2643a8840f6c27d533eb5d2fddb5e8b2/invoke.js"></script>',
            'enabled' => true
        ),
        'banner_4' => array(
            'code' => '<script>
  atOptions = {
    \'key\' : \'c1e3aa9956b9b18f6afb88394c3760ad\',
    \'format\' : \'iframe\',
    \'height\' : 90,
    \'width\' : 728,
    \'params\' : {}
  };
</script>
<script src="https://www.highperformanceformat.com/c1e3aa9956b9b18f6afb88394c3760ad/invoke.js"></script>',
            'enabled' => false // Adult - default OFF
        ),
        'banner_5' => array(
            'code' => '<script>
  atOptions = {
    \'key\' : \'a1793de7e4eb89351da28aeeb23b3277\',
    \'format\' : \'iframe\',
    \'height\' : 50,
    \'width\' : 320,
    \'params\' : {}
  };
</script>
<script src="https://www.highperformanceformat.com/a1793de7e4eb89351da28aeeb23b3277/invoke.js"></script>',
            'enabled' => false // Adult - default OFF
        ),
        'banner_6' => array(
            'code' => '<script>
  atOptions = {
    \'key\' : \'ee11ae29d4c28c5e46e127da5c558626\',
    \'format\' : \'iframe\',
    \'height\' : 60,
    \'width\' : 468,
    \'params\' : {}
  };
</script>
<script src="https://www.highperformanceformat.com/ee11ae29d4c28c5e46e127da5c558626/invoke.js"></script>',
            'enabled' => false // Adult - default OFF
        ),
        'banner_7' => array('code' => '', 'enabled' => false),
        'banner_8' => array('code' => '', 'enabled' => false),
        'banner_9' => array('code' => '', 'enabled' => false),
        'banner_10' => array('code' => '', 'enabled' => false),
    );
}

/**
 * Plugin activation - set default ads
 */
register_activation_hook( __FILE__, function() {
    $existing_ads = get_option( 'pan_resizer_ads', array() );
    
    // Only set defaults if not already configured
    if ( empty( $existing_ads ) ) {
        update_option( 'pan_resizer_ads', pan_get_default_ads() );
    } else {
        // Migrate old string format to new array format
        $defaults = pan_get_default_ads();
        $migrated = array();
        
        foreach ( $defaults as $key => $default ) {
            if ( isset( $existing_ads[$key] ) ) {
                if ( is_string( $existing_ads[$key] ) ) {
                    // Old format - migrate to new
                    $migrated[$key] = array(
                        'code' => $existing_ads[$key],
                        'enabled' => !empty( $existing_ads[$key] )
                    );
                } else {
                    // Already new format
                    $migrated[$key] = $existing_ads[$key];
                }
            } else {
                // Use default
                $migrated[$key] = $default;
            }
        }
        
        update_option( 'pan_resizer_ads', $migrated );
    }
});

// Register admin menu
add_action( 'admin_menu', function() {
    add_theme_page(
        'PAN Resizer Ads',
        'Ads Manager',
        'manage_options',
        'pan-resizer-ads',
        'pan_resizer_ads_page'
    );
});

// (Continued in next file due to length...)
